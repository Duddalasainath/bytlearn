java -jar /spring-boot-2-hello-world-1.0.2-SNAPSHOT.jar
